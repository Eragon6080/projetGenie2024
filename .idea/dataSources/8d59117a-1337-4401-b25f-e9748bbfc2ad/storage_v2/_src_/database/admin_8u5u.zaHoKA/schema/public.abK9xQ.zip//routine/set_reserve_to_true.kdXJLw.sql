create function set_reserve_to_true() returns trigger
    language plpgsql
as
$$
    DECLARE nbPersonnesForSujet INT;
    DECLARE nbPersonnesEffectif INT;
    DECLARE nbPersonneAffecte INT;
BEGIN
    select nbPersonnes into nbPersonnesForSujet from sujet where Sujet.idSujet = NEW.idSujet;
    select count(*) into nbPersonnesEffectif from selectionsujet where SelectionSujet.idSujet = NEW.idSujet;

    nbPersonneAffecte := nbPersonnesForSujet - nbPersonnesEffectif;

    IF nbPersonneAffecte = 0 THEN
        -- RAISE NOTICE '%', nbPersonneAffecte; Cette ligne permet d'afficher des informations à la console
        UPDATE Sujet SET estreserve = TRUE WHERE idSujet = NEW.idSujet;
        RETURN NEW;
    END IF;
    RETURN NEW;
END
$$;

alter function set_reserve_to_true() owner to admin;

