create function check_not_below_for_assignation_for_a_subject() returns trigger
    language plpgsql
as
$$

      DECLARE nbPersonnesForSujet INT;
      DECLARE nbPersonnesEffectif INT;
      DECLARE est_reserve BOOLEAN;
      DECLARE nbPersonneAffecte INT;
BEGIN
  select nbPersonnes into nbPersonnesForSujet from sujet where Sujet.idSujet = NEW.idSujet;
  select count(*) into nbPersonnesEffectif from selectionsujet where SelectionSujet.idSujet = NEW.idSujet;
  select estreserve into est_reserve from sujet where Sujet.idSujet = NEW.idSujet;

  IF est_reserve = TRUE THEN
    RAISE EXCEPTION 'Le sujet est déjà pris';
  ELSE
    nbPersonneAffecte := nbPersonnesForSujet - nbPersonnesEffectif;
    IF nbPersonneAffecte > 1 THEN
      RETURN NEW;
    ELSE
      IF nbPersonneAffecte = 1 THEN
        UPDATE sujet SET estReserve = TRUE WHERE Sujet.idSujet = NEW.idSujet;
        RETURN NEW;
      ELSE
        RAISE EXCEPTION 'Le nombre de personnes pour ce sujet est atteint';
      END IF;
    END IF;
  END IF;

END
$$;

alter function check_not_below_for_assignation_for_a_subject() owner to admin;

