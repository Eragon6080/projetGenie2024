create function update_sujet_mark() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE Sujet
  SET mark = (
    SELECT COALESCE(SUM(FichierDelivrable.note) / NULLIF(COUNT(FichierDelivrable.note), 0), 0)
    FROM FichierDelivrable
    INNER JOIN Delivrable ON FichierDelivrable.iddelivrable = Delivrable.iddelivrable
    INNER JOIN SelectionSujet ON FichierDelivrable.idetudiant = SelectionSujet.idetudiant
    WHERE SelectionSujet.idsujet = NEW.idsujet
  )
  WHERE idsujet = NEW.idsujet;
  RETURN NEW;
END;
$$;

alter function update_sujet_mark() owner to admin;

