create function set_is_involved() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.idEtudiant IS NOT NULL AND NEW.idSujet IS NOT NULL THEN
    NEW.is_involved = TRUE;
  END IF;
  RETURN NEW;
END
$$;

alter function set_is_involved() owner to admin;

