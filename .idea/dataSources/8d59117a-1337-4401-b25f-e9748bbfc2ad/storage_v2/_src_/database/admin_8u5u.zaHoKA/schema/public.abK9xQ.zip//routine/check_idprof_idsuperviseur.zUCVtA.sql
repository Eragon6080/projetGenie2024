create function check_idprof_idsuperviseur() returns trigger
    language plpgsql
as
$$
     DECLARE idProf INT;
     DECLARE idSupervis INT;
BEGIN
   select idProfesseur into idProf from sujet where Sujet.idProfesseur = NEW.idProfesseur;
   select Sujet.idSuperviseur into idSupervis from sujet where Sujet.idSuperviseur = NEW.idSuperviseur;

    IF NEW.idprofesseur IS NOT NULL AND NEW.idsuperviseur IS NOT NULL THEN
        RAISE EXCEPTION 'Un sujet ne peut pas avoir à la fois un idProf et un idsuperviseur. Un des deux doit être NULL.';
    END IF;

   IF idProf IS NOT NULL and idSupervis IS NULL THEN
       RETURN NEW;
    END IF;
   IF NEW.idprofesseur is NULL and NEW.idsuperviseur is not NULL THEN
       RETURN NEW;
    END IF;
    IF NEW.idprofesseur IS NOT NULL and NEW.idsuperviseur IS NULL THEN
        RETURN NEW;
    END IF;
END
$$;

alter function check_idprof_idsuperviseur() owner to admin;

